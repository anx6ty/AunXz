// Sticky messages: one persistent embed per text channel, with author-bound setup panels.
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder,
  ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle,
  PermissionFlagsBits, EmbedBuilder
} = require('discord.js');
const db = require('./database');
const ui = require('./ui');

const TIMEOUT_MS = 120000;
const DEBOUNCE_MS = 850;
const sessions = new Map();
const timers = new Map();
const queues = new Map();
let botClient = null;

function key(guildId, userId) { return `${guildId}:${userId}`; }
function id(userId, action) { return `sticky:${userId}:${action}`; }
function parseData(row) {
  try { const data = JSON.parse(row?.embedData || '{}'); return data && typeof data === 'object' ? data : {}; }
  catch { return {}; }
}
function defaultDraft() { return { title: 'Server Notice', description: 'Your important message goes here.', color: '#5865F2', footer: '', image: '' }; }
function buildEmbed(data) {
  const colorText = String(data?.color || '#5865F2').replace(/^#/, '');
  const color = /^[0-9a-f]{6}$/i.test(colorText) ? parseInt(colorText, 16) : 0x5865F2;
  const embed = new EmbedBuilder().setColor(color).setTitle(String(data?.title || 'Server Notice').slice(0, 256));
  const description = String(data?.description || '').slice(0, 4096);
  if (description) embed.setDescription(description);
  if (data?.footer) embed.setFooter({ text: String(data.footer).slice(0, 2048) });
  if (data?.image) embed.setImage(String(data.image));
  embed.setTimestamp();
  return embed;
}
function parsePreview(data, row) {
  const enabled = row ? Boolean(row.enabled) : false;
  const embed = ui.base('📌 Sticky Message Manager')
    .setDescription('Choose a text channel, edit the embed, then save. The bot re-posts it after members chat so it stays at the bottom of the channel.')
    .addFields(
      { name: 'Selected Channel', value: row?.channelId ? `<#${row.channelId}>` : 'Choose a channel below', inline: true },
      { name: 'Status', value: row ? (enabled ? '🟢 Enabled' : '🔴 Disabled') : 'Not saved yet', inline: true },
      { name: 'Saved Message', value: row?.lastMessageId ? 'Tracked' : 'Not posted yet', inline: true },
      { name: 'Manage', value: 'Edit Embed • Save • Preview • Toggle • Remove • List', inline: false }
    );
  return [embed, buildEmbed(data)];
}
function panelPayload(session) {
  const row = session.row;
  const canEdit = Boolean(session.channelId);
  const dest = new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder()
    .setCustomId(id(session.userId, 'channel')).setPlaceholder('Choose a destination / saved sticky channel')
    .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1));
  const actions = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(id(session.userId, 'edit')).setLabel('Edit Embed').setEmoji('✏️').setStyle(ButtonStyle.Primary).setDisabled(!canEdit || session.view === 'list'),
    new ButtonBuilder().setCustomId(id(session.userId, 'save')).setLabel(row ? 'Save Changes' : 'Save Sticky').setEmoji('💾').setStyle(ButtonStyle.Success).setDisabled(!canEdit || session.view === 'list'),
    new ButtonBuilder().setCustomId(id(session.userId, 'preview')).setLabel('Preview').setEmoji('👁️').setStyle(ButtonStyle.Secondary).setDisabled(!canEdit || session.view === 'list'),
    new ButtonBuilder().setCustomId(id(session.userId, 'toggle')).setLabel(row?.enabled ? 'Disable' : 'Enable').setEmoji(row?.enabled ? '🔴' : '🟢').setStyle(row?.enabled ? ButtonStyle.Danger : ButtonStyle.Success).setDisabled(!row || session.view === 'list')
  );
  let third;
  if (session.confirmRemove) {
    third = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(id(session.userId, 'confirm-remove')).setLabel('Confirm Remove').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
      new ButtonBuilder().setCustomId(id(session.userId, 'cancel-remove')).setLabel('Keep Sticky').setStyle(ButtonStyle.Secondary)
    );
  } else {
    third = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(id(session.userId, 'remove')).setLabel('Remove').setEmoji('🗑️').setStyle(ButtonStyle.Danger).setDisabled(!row || session.view === 'list'),
      new ButtonBuilder().setCustomId(id(session.userId, 'list')).setLabel(session.view === 'list' ? 'Back to Setup' : 'List Stickies').setEmoji('📚').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(id(session.userId, 'cancel')).setLabel('Cancel').setStyle(ButtonStyle.Secondary)
    );
  }
  const payload = { embeds: parsePreview(session.draft, row), components: [dest, actions, third] };
  if (session.view === 'list') {
    const all = db.listStickyMessages(session.guildId);
    const total = Math.max(1, Math.ceil(all.length / 5));
    session.page = Math.min(total, Math.max(1, session.page || 1));
    const slice = all.slice((session.page - 1) * 5, session.page * 5);
    payload.embeds = [ui.base('📚 Sticky Messages').setDescription(slice.map((item, i) =>
      `**${(session.page - 1) * 5 + i + 1}.** <#${item.channelId}> — ${item.enabled ? '🟢 Enabled' : '🔴 Disabled'}\n` +
      `• ${parseData(item).title || 'Untitled'}\n• Message: ${item.lastMessageId ? 'tracked' : 'not posted'}`
    ).join('\n\n') || 'No sticky messages have been saved yet.')
      .setFooter({ text: `Page ${session.page}/${total} • ${all.length} channel(s)` })];
    const pages = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(id(session.userId, 'first')).setLabel('First').setStyle(ButtonStyle.Secondary).setDisabled(session.page <= 1),
      new ButtonBuilder().setCustomId(id(session.userId, 'prev')).setLabel('Previous').setStyle(ButtonStyle.Secondary).setDisabled(session.page <= 1),
      new ButtonBuilder().setCustomId(id(session.userId, 'page')).setLabel(`${session.page}/${total}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
      new ButtonBuilder().setCustomId(id(session.userId, 'next')).setLabel('Next').setStyle(ButtonStyle.Secondary).setDisabled(session.page >= total),
      new ButtonBuilder().setCustomId(id(session.userId, 'last')).setLabel('Last').setStyle(ButtonStyle.Secondary).setDisabled(session.page >= total)
    );
    payload.components = [dest, third, pages];
  }
  return payload;
}
function clearSession(session) {
  clearTimeout(session.timer);
  sessions.delete(key(session.guildId, session.userId));
}
function scheduleExpiry(session) {
  clearTimeout(session.timer);
  session.timer = setTimeout(async () => {
    const msg = session.message;
    clearSession(session);
    if (msg?.edit) await msg.edit({ embeds: [ui.warnEmbed('Panel Expired', 'Run `/stickymessage` to open a new panel.')], components: [] }).catch(() => {});
  }, TIMEOUT_MS);
  session.timer.unref?.();
}
async function openPanel(interaction) {
  if (!interaction.guildId || !interaction.guild) return interaction.reply({ embeds: [ui.errorEmbed('Server Only', 'Use `/stickymessage` inside a server.')], ephemeral: true });
  const memberPerms = interaction.member?.permissions;
  if (!memberPerms?.has(PermissionFlagsBits.ManageGuild) || !memberPerms?.has(PermissionFlagsBits.ManageChannels))
    return interaction.reply({ embeds: [ui.errorEmbed('Missing Permissions', 'You need **Manage Server** and **Manage Channels** to configure sticky messages.')], ephemeral: true });
  const k = key(interaction.guildId, interaction.user.id);
  const session = { guildId: interaction.guildId, userId: interaction.user.id, channelId: null, row: null, draft: defaultDraft(), view: 'setup', page: 1, confirmRemove: false, message: null, timer: null };
  sessions.set(k, session);
  const payload = { ...panelPayload(session), ephemeral: true };
  if (typeof interaction.fetchReply === 'function') payload.fetchReply = true;
  const result = await interaction.reply(payload);
  if (result?.edit) session.message = result;
  else if (typeof interaction.fetchReply === 'function') session.message = await interaction.fetchReply().catch(() => null);
  session.expiresAt = Date.now() + TIMEOUT_MS;
  scheduleExpiry(session);
  return result;
}
function needBotPermissions(channel, guild) {
  if (!channel?.isTextBased?.() || !channel.messages?.fetch) return 'The selected channel is not a usable text channel.';
  const me = guild.members.me;
  if (!me) return 'I could not resolve my bot member in this server. Re-invite the bot and try again.';
  const perms = channel.permissionsFor(me);
  const required = [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageMessages];
  const missing = required.filter(p => !perms?.has(p));
  if (missing.length) {
    const labels = [['ViewChannel','View Channel'],['SendMessages','Send Messages'],['EmbedLinks','Embed Links'],['ManageMessages','Manage Messages']];
    const flags = missing.map(p => labels.find(([name]) => PermissionFlagsBits[name] === p)?.[1] || 'required permission');
    return `I need **${flags.join('**, **')}** in <#${channel.id}>. Update the channel permission overrides and try again.`;
  }
  return null;
}
async function saveSticky(session, interaction) {
  const guild = interaction.guild;
  const channel = guild?.channels?.cache?.get(session.channelId) || await guild?.channels?.fetch(session.channelId).catch(() => null);
  if (!channel) return interaction.reply({ embeds: [ui.errorEmbed('Channel Deleted', 'The selected channel no longer exists. Select another channel and save again.')], ephemeral: true });
  const permissionError = needBotPermissions(channel, guild);
  if (permissionError) return interaction.reply({ embeds: [ui.errorEmbed('Missing Channel Permissions', permissionError)], ephemeral: true });
  if (!String(session.draft.title || '').trim() || !String(session.draft.description || '').trim())
    return interaction.reply({ embeds: [ui.errorEmbed('Incomplete Embed', 'Set both an embed title and description before saving.')], ephemeral: true });
  try { buildEmbed(session.draft).toJSON(); }
  catch (error) { return interaction.reply({ embeds: [ui.errorEmbed('Invalid Embed', String(error?.message || error).slice(0, 700))], ephemeral: true }); }
  const prior = db.getStickyByChannel(channel.id);
  const enabled = prior ? Boolean(prior.enabled) : true;
  let sent = null;
  if (enabled) {
    try { sent = await channel.send({ embeds: [buildEmbed(session.draft)], allowedMentions: { parse: [] } }); }
    catch (error) { console.error('[StickyMessage] Could not post sticky:', error); return interaction.reply({ embeds: [ui.errorEmbed('Post Failed', `Discord rejected the sticky message: ${String(error?.message || error).slice(0, 500)}`)], ephemeral: true }); }
  }
  db.upsertStickyMessage(interaction.guildId, channel.id, JSON.stringify(session.draft), sent?.id || null, enabled, interaction.user.id);
  if (sent && prior?.lastMessageId && prior.lastMessageId !== sent.id) {
    const old = await channel.messages.fetch(prior.lastMessageId).catch(() => null);
    if (old) await old.delete().catch(error => console.warn('[StickyMessage] Previous sticky could not be deleted:', error?.message || error));
  }
  session.row = db.getStickyByChannel(channel.id);
  session.channelId = channel.id;
  session.draft = { ...session.draft };
  session.view = 'setup';
  return interaction.reply({ embeds: [ui.okEmbed('Sticky Saved', enabled ? `The sticky embed is posted and being tracked in ${channel}.` : `The sticky embed was saved for ${channel}, but the sticky is currently disabled.`)], ephemeral: true });
}
async function toggleSticky(session, interaction) {
  const row = db.getStickyByChannel(session.channelId);
  if (!row) return interaction.reply({ embeds: [ui.errorEmbed('Sticky Not Found', 'Choose a channel with a saved sticky first.')], ephemeral: true });
  const channel = interaction.guild.channels.cache.get(row.channelId) || await interaction.guild.channels.fetch(row.channelId).catch(() => null);
  if (!channel) { db.deleteStickyMessage(row.channelId); return interaction.reply({ embeds: [ui.errorEmbed('Channel Deleted', 'That sticky channel was deleted. Its saved record has been removed.')], ephemeral: true }); }
  const error = needBotPermissions(channel, interaction.guild);
  if (error) return interaction.reply({ embeds: [ui.errorEmbed('Missing Channel Permissions', error)], ephemeral: true });
  if (row.enabled) {
    if (row.lastMessageId) { const old = await channel.messages.fetch(row.lastMessageId).catch(() => null); if (old) await old.delete().catch(() => {}); }
    db.upsertStickyMessage(row.guildId, row.channelId, row.embedData, null, false, row.updatedBy);
    session.row = db.getStickyByChannel(row.channelId);
    return interaction.reply({ embeds: [ui.okEmbed('Sticky Disabled', `Automatic reposting is disabled in ${channel}.`) ], ephemeral: true });
  }
  let sent;
  try { sent = await channel.send({ embeds: [buildEmbed(parseData(row))], allowedMentions: { parse: [] } }); }
  catch (error) { return interaction.reply({ embeds: [ui.errorEmbed('Enable Failed', `Could not post the sticky message: ${String(error?.message || error).slice(0, 400)}`)], ephemeral: true }); }
  db.upsertStickyMessage(row.guildId, row.channelId, row.embedData, sent.id, true, row.updatedBy);
  session.row = db.getStickyByChannel(row.channelId);
  return interaction.reply({ embeds: [ui.okEmbed('Sticky Enabled', `Automatic reposting is enabled in ${channel}.`)], ephemeral: true });
}
async function handleInteraction(interaction) {
  const customId = String(interaction.customId || '');
  if (!customId.startsWith('sticky:')) return false;
  const parts = customId.split(':');
  const userId = parts[1];
  const action = parts[2];
  if (interaction.user.id !== userId) {
    await interaction.reply({ embeds: [ui.errorEmbed('Not Your Panel', 'This is not your sticky-message panel.')], ephemeral: true }).catch(() => {});
    return true;
  }
  const session = sessions.get(key(interaction.guildId, userId));
  if (!session || Date.now() > (session.expiresAt || Infinity)) {
    await interaction.reply({ embeds: [ui.errorEmbed('Panel Expired', 'Run `/stickymessage` to open a new panel.')], ephemeral: true }).catch(() => {});
    return true;
  }
  try {
    scheduleExpiry(session);
    if (interaction.isChannelSelectMenu() && action === 'channel') {
      const channelId = interaction.values?.[0];
      const channel = interaction.guild?.channels?.cache?.get(channelId);
      if (!channel) { await interaction.reply({ embeds: [ui.errorEmbed('Channel Unavailable', 'That channel was deleted or is inaccessible. Choose another.')], ephemeral: true }); return true; }
      const error = needBotPermissions(channel, interaction.guild);
      if (error) { await interaction.reply({ embeds: [ui.errorEmbed('Missing Channel Permissions', error)], ephemeral: true }); return true; }
      session.channelId = channelId;
      session.row = db.getStickyByChannel(channelId);
      session.draft = session.row ? { ...defaultDraft(), ...parseData(session.row) } : defaultDraft();
      session.view = 'setup'; session.confirmRemove = false;
      await interaction.update(panelPayload(session));
      if (session.message?.edit) session.message = interaction.message;
      return true;
    }
    if (interaction.isModalSubmit() && action === 'modal') {
      const title = interaction.fields.getTextInputValue('title').trim();
      const description = interaction.fields.getTextInputValue('description').trim();
      const colorRaw = interaction.fields.getTextInputValue('color').trim();
      const footer = interaction.fields.getTextInputValue('footer').trim();
      const image = interaction.fields.getTextInputValue('image').trim();
      if (!title || !description) { await interaction.reply({ embeds: [ui.errorEmbed('Incomplete Embed', 'Title and description are required.')], ephemeral: true }); return true; }
      if (colorRaw && !/^#?[0-9a-f]{6}$/i.test(colorRaw)) { await interaction.reply({ embeds: [ui.errorEmbed('Invalid Color', 'Use a six-digit hex color like `#5865F2`.')], ephemeral: true }); return true; }
      if (image) { try { const u = new URL(image); if (u.protocol !== 'https:') throw new Error(); } catch { await interaction.reply({ embeds: [ui.errorEmbed('Invalid Image URL', 'Enter a complete HTTPS image URL or leave the field empty.')], ephemeral: true }); return true; } }
      session.draft = { title: title.slice(0,256), description: description.slice(0,4096), color: colorRaw ? (colorRaw.startsWith('#') ? colorRaw : `#${colorRaw}`) : '#5865F2', footer: footer.slice(0,2048), image };
      session.view = 'setup';
      const payload = panelPayload(session);
      await interaction.reply({ embeds: [ui.okEmbed('Preview Updated', 'Your draft is updated. Review the preview in the panel, then press Save Sticky.')], ephemeral: true });
      if (session.message?.edit) await session.message.edit(payload).catch(() => {});
      return true;
    }
    if (!interaction.isButton()) return false;
    if (action === 'cancel') {
      clearSession(session);
      await interaction.update({ embeds: [ui.infoEmbed('Sticky Setup Closed', 'No further changes will be made from this panel.')], components: [] });
      return true;
    }
    if (action === 'edit') {
      if (!session.channelId) { await interaction.reply({ embeds: [ui.errorEmbed('Choose a Channel', 'Select a text channel first.')], ephemeral: true }); return true; }
      const data = session.draft;
      const modal = new ModalBuilder().setCustomId(id(session.userId, 'modal')).setTitle('Edit Sticky Embed');
      const fields = [
        ['title','Title',TextInputStyle.Short,true,256,data.title],
        ['description','Description',TextInputStyle.Paragraph,true,4000,data.description],
        ['color','Color hex (e.g. #5865F2)',TextInputStyle.Short,false,7,data.color],
        ['footer','Optional footer',TextInputStyle.Short,false,200,data.footer],
        ['image','Optional HTTPS image URL',TextInputStyle.Short,false,500,data.image]
      ];
      for (const [customId,label,style,required,maxLength,value] of fields) {
        const input = new TextInputBuilder().setCustomId(customId).setLabel(label).setStyle(style).setRequired(required).setMaxLength(maxLength);
        if (value) input.setValue(String(value).slice(0,maxLength));
        modal.addComponents(new ActionRowBuilder().addComponents(input));
      }
      await interaction.showModal(modal);
      return true;
    }
    if (action === 'save') {
      const channel = interaction.guild?.channels?.cache?.get(session.channelId);
      if (!channel) { await interaction.reply({ embeds: [ui.errorEmbed('Channel Deleted', 'Select a valid text channel before saving.')], ephemeral: true }); return true; }
      await saveSticky(session, interaction);
      await interaction.message.edit(panelPayload(session)).catch(() => {});
      return true;
    }
    if (action === 'preview') {
      await interaction.reply({ embeds: [buildEmbed(session.draft)], ephemeral: true });
      return true;
    }
    if (action === 'toggle') { await toggleSticky(session, interaction); await interaction.message.edit(panelPayload(session)).catch(() => {}); return true; }
    if (action === 'remove') {
      if (!session.row) { await interaction.reply({ embeds: [ui.errorEmbed('No Sticky', 'Select a channel with a saved sticky first.')], ephemeral: true }); return true; }
      session.confirmRemove = true;
      await interaction.update(panelPayload(session)); return true;
    }
    if (action === 'cancel-remove') { session.confirmRemove = false; await interaction.update(panelPayload(session)); return true; }
    if (action === 'confirm-remove') {
      const row = db.getStickyByChannel(session.channelId);
      if (!row) { session.confirmRemove = false; await interaction.update(panelPayload(session)); return true; }
      const channel = interaction.guild.channels.cache.get(row.channelId) || await interaction.guild.channels.fetch(row.channelId).catch(() => null);
      if (!channel) { db.deleteStickyMessage(row.channelId); session.row = null; session.confirmRemove = false; await interaction.update(panelPayload(session)); return true; }
      const error = needBotPermissions(channel, interaction.guild);
      if (error) { await interaction.reply({ embeds: [ui.errorEmbed('Missing Channel Permissions', error)], ephemeral: true }); return true; }
      if (row.lastMessageId) { const old = await channel.messages.fetch(row.lastMessageId).catch(() => null); if (old) await old.delete().catch(() => {}); }
      db.deleteStickyMessage(row.channelId); session.row = null; session.confirmRemove = false; session.draft = defaultDraft();
      await interaction.update(panelPayload(session)); return true;
    }
    if (action === 'list') { session.view = session.view === 'list' ? 'setup' : 'list'; session.page = 1; await interaction.update(panelPayload(session)); return true; }
    if (['first','prev','next','last'].includes(action)) {
      const total = Math.max(1, Math.ceil(db.listStickyMessages(session.guildId).length / 5));
      session.page = action === 'first' ? 1 : action === 'last' ? total : action === 'prev' ? Math.max(1, session.page - 1) : Math.min(total, session.page + 1);
      await interaction.update(panelPayload(session)); return true;
    }
    return false;
  } catch (error) {
    console.error('[StickyMessage] Panel handler failed:', error);
    const payload = { embeds: [ui.errorEmbed('Sticky Message Error', String(error?.message || error).slice(0, 1200))], ephemeral: true };
    if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => {}); else await interaction.reply(payload).catch(() => {});
    return true;
  }
}
function start(client) { botClient = client; }
async function handleMessage(message) {
  if (!message?.guild || message.author?.bot) return;
  const row = db.getStickyByChannel(message.channelId);
  if (!row?.enabled) return;
  clearTimeout(timers.get(message.channelId));
  const timer = setTimeout(() => {
    timers.delete(message.channelId);
    const prior = queues.get(message.channelId) || Promise.resolve();
    const next = prior.catch(() => {}).then(async () => {
      const current = db.getStickyByChannel(message.channelId);
      if (!current?.enabled || !botClient) return;
      const guild = botClient.guilds.cache.get(current.guildId);
      const channel = guild?.channels?.cache?.get(current.channelId) || await guild?.channels?.fetch(current.channelId).catch(() => null);
      if (!channel) { db.deleteStickyMessage(current.channelId); console.warn(`[StickyMessage] Removed deleted channel ${current.channelId} from storage.`); return; }
      const error = needBotPermissions(channel, guild);
      if (error) { console.error(`[StickyMessage] ${error}`); return; }
      const previous = current.lastMessageId ? await channel.messages.fetch(current.lastMessageId).catch(() => null) : null;
      let sent;
      try { sent = await channel.send({ embeds: [buildEmbed(parseData(current))], allowedMentions: { parse: [] } }); }
      catch (err) { console.error(`[StickyMessage] Repost failed in ${channel.id}:`, err); return; }
      db.upsertStickyMessage(current.guildId, current.channelId, current.embedData, sent.id, true, current.updatedBy);
      if (previous && previous.id !== sent.id) await previous.delete().catch(err => console.warn('[StickyMessage] Old message cleanup failed:', err?.message || err));
    }).finally(() => { if (queues.get(message.channelId) === next) queues.delete(message.channelId); });
    queues.set(message.channelId, next);
  }, DEBOUNCE_MS);
  timer.unref?.();
  timers.set(message.channelId, timer);
}
async function command(interaction) { return openPanel(interaction); }
module.exports = { command, handleInteraction, handleMessage, start, buildEmbed };
