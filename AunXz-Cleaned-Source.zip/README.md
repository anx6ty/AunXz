# AunXz — existing bot source with additive fixes

This package keeps AunXz's existing `index.js` + `commands.js` handler structure and SQLite database, with additional stat channels, AFK, sniping, pagination, and purge support. It is a full source package—not a replacement architecture. Do not replace just `index.js` or `commands.js` without keeping the supporting modules listed below.

## Source files

- `index.js` — Discord client, gateway events, slash/prefix command routing, registration and background services.
- `commands.js` — slash command builders and command handlers, including `/setupstats`, `/afk`, `/purge`, `/snipe`, `/massrole` and `/serverinfo`.
- `database.js` — persistent SQLite schema and additive migrations for existing databases, stat channels, and AFK records.
- `activityFeatures.js` — AFK state and ping history; in-memory, 24-hour snipe history and pagination.
- `statsetup.js` — `/statsetup` compatibility flow, `/setupstats`, official-platform API requests, and live stat-channel refresh service.
- `systems.js`, `ui.js`, `v2patch.js`, `ownerCommands.js`, `stickymessage.js`, `template.js`, `embeds.js` — supporting modules referenced by the active source.
- `package.json` — start script and dependencies.
- `.env.example` — configuration reference.

## Run / deploy

Use Node.js 18.17+ (Node 20+ is preferable), then run:

```sh
npm install
npm start
```

Slash commands are registered by `index.js` when the client becomes ready. `npm start` is the supported entry point; there is no separate `commandData.js` file or standalone deploy script in this source set.

On Railway, set `DISCORD_TOKEN`, `CLIENT_ID`, and `OWNER_IDS` in the service Variables. Set `OWNER_GUILD_ID` if owner-only slash commands should be registered in a particular guild. Set `DATABASE_PATH` to a file on a persistent Railway Volume if you need the database to survive container replacement. Do not commit live tokens or API credentials.

## Discord Developer Portal intents and permissions

Enable these privileged intents in the Developer Portal and keep them enabled in `index.js`:

- **Server Members Intent** — required for accurate member/bot counts, `/massrole`, and AFK member-presence checks.
- **Message Content Intent** — required for AFK text events and snipe content capture.
- **Presence Intent** — required for the optional `online` stat.

The bot also needs suitable server/channel permissions for commands. For example, `/purge` needs **Manage Messages** from both the user and bot; `/massrole` needs **Manage Roles** and role hierarchy access; `/setupstats` needs **Manage Channels** and the bot needs **Manage Channels**. Snipe cannot capture content that Discord never delivered to the bot, and deleted-message content cannot be reconstructed after the bot has restarted.

## `/setupstats`

The setup panel is ephemeral and restricted to the command user. It supports server counters (`<members>`, `<bots>`, `<staff>`, `<boosts>`, `<humans>`, `<online>`, `<roles>`, `<channels>`) and social profiles on YouTube, TikTok, Instagram and X/Twitter. Stat channels are saved to SQLite and refreshed on a ten-minute interval for `/setupstats`; member join/leave and boost changes request a debounced server-stat refresh. It respects Discord's rename rate by queueing changes after two channel-name updates in ten minutes.

Social counters require usable API credentials. Put them in Railway Variables (see `.env.example`) or configure and save a credential using the older `/statsetup` form before using `/setupstats`. Credentials are platform-specific and permissions vary:

- YouTube needs an enabled YouTube Data API v3 key.
- TikTok counters use the Research API, which is restricted to approved apps/scopes; a normal public profile link alone does not grant access.
- Instagram counters require eligible professional-account access via Meta's Instagram Graph API; personal profiles may not be available.
- X/Twitter requires an X API bearer token with access to the requested endpoint.

The bot will report API errors rather than treating an API failure as a successful count. Some counters such as recent post/video likes need additional endpoint access and may be limited by the platform's API policy.

## `/afk`

`/afk [reason]` opens Global AFK and Server AFK buttons. Global records apply across guilds where the user is present; Server records apply only in the selected guild. Ping records (including replies) are stored in SQLite and capped at 15 per AFK scope. User mentions are sent with `allowedMentions: { parse: [] }`, so replies are silent. Sending a message in a relevant guild clears the matching AFK record(s) and reports the duration and recent pings.

## `/purge`

`/purge amount:<1–10000>` supports user, bot-only, text-contains, and optional pinned-message filters. It scans with 100-message cursors, stops at the 14-day bulk-delete boundary, reports progress from the confirmation panel, and deletes in batches of 100 with a delay. Counts are based on messages the bot can fetch and delete; Discord's own API and permissions still determine what can be removed.

## `/snipe`

`/snipe` is available to Administrators or members with Manage Messages and shows the newest deleted/edited event captured for the current channel in an ephemeral, paginated panel. It keeps up to 50 events per channel for 24 hours in memory. Thus history is intentionally cleared when the process restarts. `/snipesetup` is no longer registered; it was removed in favor of `/snipe`.

## Validation notes

The JavaScript sources have been checked with `node --check`, and the new database schema and code paths were reviewed statically. A live Discord test was not possible in this environment because Discord.js and better-sqlite3 could not be installed here, and no Discord token or platform API credentials were provided. Test on a staging server before deploying to your main guild.
